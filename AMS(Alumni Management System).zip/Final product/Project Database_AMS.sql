-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2020 at 07:17 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ams`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

DROP TABLE IF EXISTS `alumni`;
CREATE TABLE IF NOT EXISTS `alumni` (
  `alumni_id` int(11) NOT NULL AUTO_INCREMENT,
  `alumni_name` varchar(555) NOT NULL,
  `alumni_contact` int(11) NOT NULL,
  `alumni_graduatingyear` int(11) NOT NULL,
  `alumni_jobdescription` varchar(555) NOT NULL,
  `alumni_companyname` varchar(555) NOT NULL,
  `alumni_designation` varchar(555) NOT NULL,
  PRIMARY KEY (`alumni_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `chat_fromname` varchar(555) NOT NULL,
  `chat_toname` varchar(555) NOT NULL,
  `chat_subject` varchar(555) NOT NULL,
  `chat_message` varchar(555) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(555) NOT NULL,
  `department_location` varchar(555) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(555) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(555) NOT NULL,
  `event_description` varchar(555) DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_empid` int(11) NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(555) NOT NULL,
  `faculty_contact` int(11) NOT NULL,
  `faculty_address` varchar(555) NOT NULL,
  `faculty_qualification` varchar(555) NOT NULL,
  PRIMARY KEY (`faculty_empid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_comment`
--

DROP TABLE IF EXISTS `forum_comment`;
CREATE TABLE IF NOT EXISTS `forum_comment` (
  `comment_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_topicID` int(11) UNSIGNED DEFAULT NULL,
  `comment_userID` int(11) UNSIGNED DEFAULT NULL,
  `comment_content` varchar(500) DEFAULT NULL,
  `comment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_topicID` (`comment_topicID`),
  KEY `comment_userID` (`comment_userID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_comment`
--

INSERT INTO `forum_comment` (`comment_ID`, `comment_topicID`, `comment_userID`, `comment_content`, `comment_date`) VALUES
(2, 15, 4, 'asdasdasd', '2018-03-03 15:35:39'),
(3, 17, 3, 'ytyutyu', '2018-03-12 08:04:12');

-- --------------------------------------------------------

--
-- Table structure for table `forum_comment_reply`
--

DROP TABLE IF EXISTS `forum_comment_reply`;
CREATE TABLE IF NOT EXISTS `forum_comment_reply` (
  `comment_reply_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_reply_topicID` int(10) UNSIGNED DEFAULT NULL,
  `comment_reply_parentID` int(11) UNSIGNED DEFAULT NULL,
  `comment_reply_userID` int(11) UNSIGNED DEFAULT NULL,
  `comment_reply_content` varchar(500) DEFAULT NULL,
  `comment_reply_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_reply_ID`),
  KEY `comment_reply_parentID` (`comment_reply_parentID`),
  KEY `comment_reply_userID` (`comment_reply_userID`),
  KEY `comment_reply_topicID` (`comment_reply_topicID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_topic`
--

DROP TABLE IF EXISTS `forum_topic`;
CREATE TABLE IF NOT EXISTS `forum_topic` (
  `topic_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_title` varchar(150) DEFAULT NULL,
  `post_owner_id` int(11) UNSIGNED DEFAULT NULL,
  `post_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `post_content` varchar(50000) DEFAULT NULL,
  `post_status` varchar(25) DEFAULT 'UNPIN',
  PRIMARY KEY (`topic_ID`),
  KEY `post_owner_id` (`post_owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_topic`
--

INSERT INTO `forum_topic` (`topic_ID`, `post_title`, `post_owner_id`, `post_date`, `post_content`, `post_status`) VALUES
(15, '1231231', 1, '2018-02-24 14:48:22', '<p>asda</p>\r\n', 'UNPIN'),
(16, 'asda', 4, '2018-02-24 15:09:46', '<p>asdasd</p>\r\n', 'UNPIN'),
(17, 'asdasdas', 3, '2018-03-12 08:03:57', '<p>d213123123</p>\r\n', 'UNPIN');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
CREATE TABLE IF NOT EXISTS `guest` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(555) NOT NULL,
  `guest_address` varchar(555) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marital_status`
--

DROP TABLE IF EXISTS `marital_status`;
CREATE TABLE IF NOT EXISTS `marital_status` (
  `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `marital_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marital_status`
--

INSERT INTO `marital_status` (`ID`, `marital_Name`) VALUES
(1, 'Single'),
(2, 'Married'),
(3, 'Widowed');

-- --------------------------------------------------------

--
-- Table structure for table `message_send`
--

DROP TABLE IF EXISTS `message_send`;
CREATE TABLE IF NOT EXISTS `message_send` (
  `message_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `message_threadID` int(11) UNSIGNED DEFAULT NULL,
  `message_sendDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message_content` varchar(1500) DEFAULT NULL,
  `message_receiver` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`message_ID`),
  KEY `message_threadID` (`message_threadID`),
  KEY `message_receiver` (`message_receiver`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_send`
--

INSERT INTO `message_send` (`message_ID`, `message_threadID`, `message_sendDate`, `message_content`, `message_receiver`) VALUES
(1, 1, '2018-02-22 15:22:11', 'waaaaaaaa', 3),
(2, 1, '2018-02-22 15:22:13', 'meeeeeeeeeeeee', 3);

-- --------------------------------------------------------

--
-- Table structure for table `message_send_state`
--

DROP TABLE IF EXISTS `message_send_state`;
CREATE TABLE IF NOT EXISTS `message_send_state` (
  `state_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `state_msgID` int(11) UNSIGNED DEFAULT NULL,
  `state_readerID` int(11) UNSIGNED DEFAULT NULL,
  `state_dateRead` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`state_ID`),
  KEY `state_msgID` (`state_msgID`),
  KEY `state_readerID` (`state_readerID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_send_state`
--

INSERT INTO `message_send_state` (`state_ID`, `state_msgID`, `state_readerID`, `state_dateRead`) VALUES
(1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `message_thread`
--

DROP TABLE IF EXISTS `message_thread`;
CREATE TABLE IF NOT EXISTS `message_thread` (
  `thread_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `thread_name` varchar(150) DEFAULT NULL,
  `thread_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`thread_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_thread`
--

INSERT INTO `message_thread` (`thread_ID`, `thread_name`, `thread_created`) VALUES
(1, '64564', '2018-02-22 15:19:21');

-- --------------------------------------------------------

--
-- Table structure for table `message_thread_participant`
--

DROP TABLE IF EXISTS `message_thread_participant`;
CREATE TABLE IF NOT EXISTS `message_thread_participant` (
  `participant_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `participant_threadID` int(11) UNSIGNED DEFAULT NULL,
  `participant_userID` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`participant_ID`),
  KEY `participant_threadID` (`participant_threadID`),
  KEY `participant_userID` (`participant_userID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_thread_participant`
--

INSERT INTO `message_thread_participant` (`participant_ID`, `participant_threadID`, `participant_userID`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mmu_college`
--

DROP TABLE IF EXISTS `mmu_college`;
CREATE TABLE IF NOT EXISTS `mmu_college` (
  `colleges_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `college_name` varchar(150) DEFAULT NULL,
  `college_acronym` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`colleges_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mmu_college`
--

INSERT INTO `mmu_college` (`colleges_ID`, `college_name`, `college_acronym`) VALUES
(1, 'College of Engineering and Information Technology', 'CEIT'),
(2, 'College of Art and Sciences', 'CAS');

-- --------------------------------------------------------

--
-- Table structure for table `mmu_course`
--

DROP TABLE IF EXISTS `mmu_course`;
CREATE TABLE IF NOT EXISTS `mmu_course` (
  `course_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_departmentID` int(11) UNSIGNED DEFAULT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_acronym` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`course_ID`),
  KEY `course_departmentID` (`course_departmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mmu_course`
--

INSERT INTO `mmu_course` (`course_ID`, `course_departmentID`, `course_name`, `course_acronym`) VALUES
(1, 2, 'Bachelor of Science in Information Technology', 'BSIT'),
(2, 2, 'Bachelor of Science in Computer Science', 'BSCS'),
(3, 2, 'Bachelor of Science in Office Administration', 'BSOA'),
(4, 1, 'B.Tech CSE Software Development', 'CS-SD');

-- --------------------------------------------------------

--
-- Table structure for table `mmu_department`
--

DROP TABLE IF EXISTS `mmu_department`;
CREATE TABLE IF NOT EXISTS `mmu_department` (
  `department_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_collegeID` int(11) UNSIGNED DEFAULT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `department_acronym` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`department_ID`),
  KEY `department_collegeID` (`department_collegeID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mmu_department`
--

INSERT INTO `mmu_department` (`department_ID`, `department_collegeID`, `department_name`, `department_acronym`) VALUES
(1, 1, 'Computer Science', 'CSE'),
(2, 1, 'Information Technology', 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

DROP TABLE IF EXISTS `posting`;
CREATE TABLE IF NOT EXISTS `posting` (
  `posting_id` int(11) NOT NULL AUTO_INCREMENT,
  `posting_description` varchar(500) NOT NULL,
  `posting_title` varchar(500) NOT NULL,
  `posting_type` varchar(500) NOT NULL,
  UNIQUE KEY `posting_id` (`posting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(555) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_rollnumber` int(11) NOT NULL AUTO_INCREMENT,
  `student_address` varchar(555) NOT NULL,
  `student_contact` int(11) NOT NULL,
  `student_name` varchar(555) NOT NULL,
  `student_email` varchar(555) NOT NULL,
  `student_branch/course` varchar(555) NOT NULL,
  PRIMARY KEY (`student_rollnumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `suggested_job`
--

DROP TABLE IF EXISTS `suggested_job`;
CREATE TABLE IF NOT EXISTS `suggested_job` (
  `job_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_Title` varchar(250) DEFAULT NULL,
  `job_Course` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`job_ID`),
  KEY `job_Course` (`job_Course`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suggested_job`
--

INSERT INTO `suggested_job` (`job_ID`, `job_Title`, `job_Course`) VALUES
(1, 'Web Developer', 1),
(2, 'Data Analysis', 1),
(3, 'Database Administrator', 3),
(5, 'Computer Support Specialist', 1),
(6, 'Computer Network Architect', 1),
(7, 'Information Security Analyst', 1),
(8, 'Software Developer', 1),
(9, 'Application Developer', 1),
(10, 'Applications Engineer', 1),
(11, 'Associate Developer', 1),
(12, 'Computer Programmer', 1),
(13, 'Data Quality Manager', 1),
(14, 'Desktop Support Specialist', 1),
(15, 'Desktop Support Manager', 1),
(16, 'Computer Support Specialist', 2),
(17, 'Computer Network Architect', 2),
(18, 'Information Security Analyst', 2),
(19, 'Software Developer', 2),
(20, 'Application Developer', 2),
(21, 'Applications Engineer', 2),
(22, 'Associate Developer', 2),
(23, 'Computer Programmer', 2),
(24, 'Data Quality Manager', 2),
(25, 'Desktop Support Specialist', 2),
(26, 'Desktop Support Manager', 2),
(30, 'Receptionist', 3),
(31, 'Administration Assistant', 3),
(33, 'Office Manager', 3),
(34, 'Personal Assistant', 3),
(35, 'Executive Assistant', 3),
(36, 'Virtual Assistant', 3);

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
CREATE TABLE IF NOT EXISTS `survey` (
  `survey_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `survey_name` varchar(255) DEFAULT NULL,
  `survey_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visibility` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`survey_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`survey_ID`, `survey_name`, `survey_date`, `visibility`) VALUES
(1, 'survey 1', '2018-05-04 17:25:50', 1),
(2, 'survey 2', '2018-05-04 17:25:50', 0),
(10, 'asdasdasd', '2018-05-01 09:11:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `survey_answer`
--

DROP TABLE IF EXISTS `survey_answer`;
CREATE TABLE IF NOT EXISTS `survey_answer` (
  `a_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `survey_aID` int(11) UNSIGNED DEFAULT NULL,
  `user_ID` int(11) DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`a_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_answer`
--

INSERT INTO `survey_answer` (`a_ID`, `survey_aID`, `user_ID`, `form_id`) VALUES
(24, 4, 3, 18),
(25, 5, 3, 18),
(26, 6, 3, 18),
(27, 7, 3, 18),
(28, 17, 3, 18),
(29, 1, 3, 19),
(30, 3, 3, 19),
(31, 4, 3, 19),
(32, 5, 3, 19),
(33, 6, 3, 19),
(34, 7, 3, 19),
(35, 17, 3, 19);

-- --------------------------------------------------------

--
-- Table structure for table `survey_answer_other`
--

DROP TABLE IF EXISTS `survey_answer_other`;
CREATE TABLE IF NOT EXISTS `survey_answer_other` (
  `ao_ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_ID` int(11) DEFAULT NULL,
  `survey_aID` int(11) NOT NULL,
  `survey_aString` varchar(250) DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ao_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_answer_other`
--

INSERT INTO `survey_answer_other` (`ao_ID`, `user_ID`, `survey_aID`, `survey_aString`, `form_id`) VALUES
(10, 3, 2, '11111111111111', 18),
(11, 3, 8, '1111111111111111111', 18);

-- --------------------------------------------------------

--
-- Table structure for table `survey_anweroptions`
--

DROP TABLE IF EXISTS `survey_anweroptions`;
CREATE TABLE IF NOT EXISTS `survey_anweroptions` (
  `survey_aID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `survey_qID` int(11) UNSIGNED DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`survey_aID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_anweroptions`
--

INSERT INTO `survey_anweroptions` (`survey_aID`, `survey_qID`, `answer`) VALUES
(1, 1, 'aaaaa'),
(2, 1, 'other(s)'),
(3, 2, 'aa'),
(4, 3, 'bb'),
(5, 4, 'a'),
(6, 5, 'b'),
(7, 6, 'aa'),
(8, 2, 'other(s)'),
(10, 8, 'asdasd'),
(11, 8, 'asdasdasd'),
(12, 8, '31'),
(13, 8, '2'),
(15, 9, 'a'),
(16, 9, 'b'),
(17, 7, 'c'),
(18, 9, '123'),
(19, 10, 'asdasdasd'),
(20, 10, 'asdd'),
(21, 10, 'dsd');

-- --------------------------------------------------------

--
-- Table structure for table `survey_forms`
--

DROP TABLE IF EXISTS `survey_forms`;
CREATE TABLE IF NOT EXISTS `survey_forms` (
  `form_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `form_ownerID` int(11) UNSIGNED DEFAULT NULL,
  `form_taken` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `survey_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`form_id`),
  KEY `form_ownerID` (`form_ownerID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_forms`
--

INSERT INTO `survey_forms` (`form_id`, `form_ownerID`, `form_taken`, `survey_ID`) VALUES
(0, 0, '2018-02-04 12:23:39', NULL),
(1, 1, '2018-02-04 13:24:38', NULL),
(2, 1, '2018-02-07 16:41:32', NULL),
(3, 18, '2018-03-17 04:47:43', NULL),
(4, 18, '2018-03-17 04:57:57', NULL),
(5, 21, '2018-03-17 09:57:10', NULL),
(6, 22, '2018-03-17 10:00:10', NULL),
(7, 1, '2018-03-30 03:14:57', NULL),
(10, 3, '2018-05-04 15:30:07', NULL),
(11, 3, '2018-05-04 15:30:58', NULL),
(12, 3, '2018-05-04 16:12:47', 1),
(13, 3, '2018-05-04 17:09:01', 1),
(14, 3, '2018-05-04 17:18:32', 1),
(15, 3, '2018-05-04 17:21:25', 2),
(16, 3, '2018-05-04 17:26:24', 1),
(17, 3, '2018-05-04 17:26:43', 1),
(18, 3, '2018-05-04 17:42:26', 1),
(19, 3, '2018-05-04 17:42:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `survey_maxcount`
--

DROP TABLE IF EXISTS `survey_maxcount`;
CREATE TABLE IF NOT EXISTS `survey_maxcount` (
  `survey_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `survey_ownerID` int(11) UNSIGNED DEFAULT NULL,
  `survey_maxattemp` int(11) DEFAULT NULL,
  `survey_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`survey_id`),
  UNIQUE KEY `survey_ownerID_2` (`survey_ownerID`),
  KEY `survey_ownerID` (`survey_ownerID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_maxcount`
--

INSERT INTO `survey_maxcount` (`survey_id`, `survey_ownerID`, `survey_maxattemp`, `survey_date`) VALUES
(1, 1, 2, '2018-05-01 07:08:27'),
(2, 3, 0, '2018-05-04 17:42:35'),
(3, 6, 2, '2018-02-18 16:00:00'),
(4, 18, 0, '2018-03-17 04:57:57'),
(5, 19, 2, '2018-03-07 17:46:58'),
(6, 21, 1, '2018-03-17 09:57:10'),
(7, 22, 1, '2018-03-17 10:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `survey_question4`
--

DROP TABLE IF EXISTS `survey_question4`;
CREATE TABLE IF NOT EXISTS `survey_question4` (
  `survey_qID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `row1` int(11) DEFAULT NULL,
  `col1` varchar(1) DEFAULT '0',
  `survey_formID` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`survey_qID`),
  KEY `survey_formID` (`survey_formID`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_question4`
--

INSERT INTO `survey_question4` (`survey_qID`, `row1`, `col1`, `survey_formID`) VALUES
(1, 1, '1', 1),
(2, 2, '1', 1),
(3, 3, '1', 1),
(4, 4, '1', 1),
(5, 5, '1', 1),
(6, 6, '1', 1),
(7, 1, '', 2),
(8, 2, '', 2),
(9, 3, '', 2),
(10, 4, '', 2),
(11, 5, '', 2),
(12, 6, '', 2),
(13, 1, '1', 3),
(14, 2, '', 3),
(15, 3, '', 3),
(16, 4, '', 3),
(17, 5, '', 3),
(18, 6, '', 3),
(19, 1, '', 4),
(20, 2, '1', 4),
(21, 3, '', 4),
(22, 4, '1', 4),
(23, 5, '', 4),
(24, 6, '1', 4),
(25, 1, '', 5),
(26, 2, '', 5),
(27, 3, '', 5),
(28, 4, '', 5),
(29, 5, '1', 5),
(30, 6, '', 5),
(31, 1, '', 6),
(32, 2, '', 6),
(33, 3, '', 6),
(34, 4, '', 6),
(35, 5, '', 6),
(36, 6, '1', 6),
(37, 1, '', 7),
(38, 2, '', 7),
(39, 3, '1', 7),
(40, 4, '1', 7),
(41, 5, '1', 7),
(42, 6, '1', 7);

-- --------------------------------------------------------

--
-- Table structure for table `survey_question5`
--

DROP TABLE IF EXISTS `survey_question5`;
CREATE TABLE IF NOT EXISTS `survey_question5` (
  `survey_qID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ans` varchar(5) DEFAULT NULL,
  `survey_formID` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`survey_qID`),
  KEY `survey_formID` (`survey_formID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_question5`
--

INSERT INTO `survey_question5` (`survey_qID`, `ans`, `survey_formID`) VALUES
(1, 'yes', 1),
(2, 'yes', 2),
(3, 'yes', 3),
(4, 'yes', 4),
(5, 'yes', 5),
(6, 'yes', 6),
(7, '', 7);

-- --------------------------------------------------------

--
-- Table structure for table `survey_question6`
--

DROP TABLE IF EXISTS `survey_question6`;
CREATE TABLE IF NOT EXISTS `survey_question6` (
  `survey_qID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ans` varchar(10) DEFAULT NULL,
  `survey_formID` int(11) UNSIGNED DEFAULT NULL,
  `job` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`survey_qID`),
  KEY `survey_formID` (`survey_formID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_question6`
--

INSERT INTO `survey_question6` (`survey_qID`, `ans`, `survey_formID`, `job`) VALUES
(1, 'temp', 1, NULL),
(2, 'rop', 2, 'Web Developer'),
(3, 'temp', 3, 'Web Developer'),
(4, 'con', 4, 'Data Scientist'),
(5, 'rop', 5, 'Executive Assistant'),
(6, 'rop', 6, 'Web Developer'),
(7, '', 7, 'asdasdasd');

-- --------------------------------------------------------

--
-- Table structure for table `survey_questionnaire`
--

DROP TABLE IF EXISTS `survey_questionnaire`;
CREATE TABLE IF NOT EXISTS `survey_questionnaire` (
  `survey_qID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `survey_ID` int(11) UNSIGNED DEFAULT NULL,
  `question` varchar(255) NOT NULL,
  PRIMARY KEY (`survey_qID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_questionnaire`
--

INSERT INTO `survey_questionnaire` (`survey_qID`, `survey_ID`, `question`) VALUES
(1, 1, 'sagutan mo to'),
(2, 1, 'asdasdasdasd'),
(3, 1, 'xxxxxxxxxxxxxxxxxxxx'),
(4, 1, '44444'),
(5, 1, 'xxxxxx'),
(6, 1, 'zzzzzzzz'),
(7, 1, '545646'),
(8, 2, '1'),
(9, 2, 'hey'),
(10, 2, '123123123123');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_password` varchar(555) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

DROP TABLE IF EXISTS `user_account`;
CREATE TABLE IF NOT EXISTS `user_account` (
  `user_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_level` int(11) UNSIGNED DEFAULT NULL,
  `user_name` varchar(25) DEFAULT NULL,
  `user_password` mediumtext,
  `user_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_ID`),
  KEY `user_level` (`user_level`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`user_ID`, `user_level`, `user_name`, `user_password`, `user_created`) VALUES
(0, 3, 'test', 'testing', '2020-05-05 06:48:01'),
(1, 1, '170012', 'Simranjeet', '2020-05-05 06:49:08'),
(3, 3, 'admin', 'admin', '2020-05-04 05:19:08'),
(4, 2, 'teacher', 'qw', '2020-05-05 06:06:23'),
(6, 2, 'daaa1', 'za', '2020-05-05 06:06:33'),
(7, 2, 'teacher', 'qaz', '2020-05-05 06:06:42'),
(8, 2, 'wazhing', 'zaq', '2020-05-05 06:06:51'),
(17, 2, 'z1', 'qwe', '2020-05-05 06:07:01'),
(18, 1, '170041', 'nikhil', '2020-05-05 06:52:42'),
(19, 1, '170018', 'garvit', '2020-05-05 06:50:40'),
(20, 2, 'zxc123', 'mmu', '2020-05-05 06:07:39'),
(21, 1, '170038', 'vaibhav', '2020-05-05 06:58:47'),
(22, 1, '170052', 'mansi', '2020-05-05 06:51:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_admin_detail`
--

DROP TABLE IF EXISTS `user_admin_detail`;
CREATE TABLE IF NOT EXISTS `user_admin_detail` (
  `admin_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_userID` int(11) UNSIGNED DEFAULT NULL,
  `admin_img` varchar(250) DEFAULT 'temp.gif',
  `admin_fName` varchar(100) DEFAULT NULL,
  `admin_mName` varchar(25) DEFAULT NULL,
  `admin_lName` varchar(50) DEFAULT NULL,
  `admin_address` varchar(250) DEFAULT NULL,
  `admin_status` varchar(10) DEFAULT 'unregister',
  `admin_gender` varchar(1) DEFAULT NULL,
  `admin_dob` date DEFAULT NULL,
  `admin_contact` varchar(11) DEFAULT NULL,
  `admin_civilStat` int(11) UNSIGNED DEFAULT NULL,
  `admin_secretquestion` varchar(250) DEFAULT NULL,
  `admin_secretanswer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`admin_ID`),
  KEY `admin_userID` (`admin_userID`),
  KEY `admin_civilStat` (`admin_civilStat`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_admin_detail`
--

INSERT INTO `user_admin_detail` (`admin_ID`, `admin_userID`, `admin_img`, `admin_fName`, `admin_mName`, `admin_lName`, `admin_address`, `admin_status`, `admin_gender`, `admin_dob`, `admin_contact`, `admin_civilStat`, `admin_secretquestion`, `admin_secretanswer`) VALUES
(1, 3, '123123.jpg', 'admin', 'admin', 'admin', 'zxczxczxc', 'register', 'M', '0000-00-00', '09169158798', 1, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

DROP TABLE IF EXISTS `user_level`;
CREATE TABLE IF NOT EXISTS `user_level` (
  `level_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`level_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`level_ID`, `level_name`) VALUES
(0, 'unregister'),
(1, 'student'),
(2, 'teacher'),
(3, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_notification`
--

DROP TABLE IF EXISTS `user_notification`;
CREATE TABLE IF NOT EXISTS `user_notification` (
  `notif_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `notif_typeID` int(11) UNSIGNED DEFAULT NULL,
  `notif_topicID` int(11) UNSIGNED DEFAULT NULL,
  `notif_userID` int(11) UNSIGNED DEFAULT NULL,
  `notif_receiverID` int(11) UNSIGNED DEFAULT NULL,
  `notif_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notif_state` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`notif_ID`),
  KEY `notif_topicID` (`notif_topicID`),
  KEY `notif_userID` (`notif_userID`),
  KEY `notif_receiverID` (`notif_receiverID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_notification`
--

INSERT INTO `user_notification` (`notif_ID`, `notif_typeID`, `notif_topicID`, `notif_userID`, `notif_receiverID`, `notif_date`, `notif_state`) VALUES
(3, NULL, NULL, NULL, NULL, '2018-02-23 16:49:20', NULL),
(4, 3, 15, 4, 1, '2018-03-03 15:35:39', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_notif_state`
--

DROP TABLE IF EXISTS `user_notif_state`;
CREATE TABLE IF NOT EXISTS `user_notif_state` (
  `status_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `status_Desc` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`status_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_notif_type`
--

DROP TABLE IF EXISTS `user_notif_type`;
CREATE TABLE IF NOT EXISTS `user_notif_type` (
  `type_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`type_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_student_detail`
--

DROP TABLE IF EXISTS `user_student_detail`;
CREATE TABLE IF NOT EXISTS `user_student_detail` (
  `student_ID` int(11) NOT NULL AUTO_INCREMENT,
  `student_userID` int(11) UNSIGNED DEFAULT NULL,
  `student_img` varchar(250) DEFAULT 'temp.gif',
  `student_IDNumber` int(11) UNSIGNED DEFAULT NULL,
  `student_fName` varchar(100) DEFAULT NULL,
  `student_mName` varchar(25) DEFAULT NULL,
  `student_lName` varchar(50) DEFAULT NULL,
  `student_address` varchar(250) DEFAULT NULL,
  `student_civilStat` int(11) UNSIGNED DEFAULT NULL,
  `student_dob` date DEFAULT NULL,
  `student_gender` varchar(1) DEFAULT NULL,
  `student_contact` varchar(11) DEFAULT NULL,
  `student_admission` date DEFAULT NULL,
  `student_year_grad` date DEFAULT NULL,
  `student_department` int(11) UNSIGNED DEFAULT NULL,
  `student_status` varchar(10) DEFAULT 'unregister',
  `student_secretquestion` varchar(250) DEFAULT NULL,
  `student_secretanswer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`student_ID`),
  KEY `student_department` (`student_department`),
  KEY `student_userID` (`student_userID`),
  KEY `student_civilStat` (`student_civilStat`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_student_detail`
--

INSERT INTO `user_student_detail` (`student_ID`, `student_userID`, `student_img`, `student_IDNumber`, `student_fName`, `student_mName`, `student_lName`, `student_address`, `student_civilStat`, `student_dob`, `student_gender`, `student_contact`, `student_admission`, `student_year_grad`, `student_department`, `student_status`, `student_secretquestion`, `student_secretanswer`) VALUES
(1, 1, 'temp.gif', 201310656, 'asd', 'asd', 'asdasd', 'asd321', 1, NULL, 'M', '21', '2018-03-06', '2018-03-30', 1, 'unregister', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_teacher_detail`
--

DROP TABLE IF EXISTS `user_teacher_detail`;
CREATE TABLE IF NOT EXISTS `user_teacher_detail` (
  `teacher_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `teacher_userID` int(11) UNSIGNED DEFAULT NULL,
  `teacher_img` varchar(250) DEFAULT 'temp.gif',
  `teacher_facultyID` int(11) UNSIGNED DEFAULT NULL,
  `teacher_fName` varchar(100) DEFAULT NULL,
  `teacher_mName` varchar(25) DEFAULT NULL,
  `teacher_lName` varchar(50) DEFAULT NULL,
  `teacher_gender` varchar(1) DEFAULT NULL,
  `teacher_dob` date DEFAULT NULL,
  `teacher_contact` varchar(11) DEFAULT NULL,
  `teacher_address` varchar(250) DEFAULT NULL,
  `teacher_civilStat` int(11) UNSIGNED DEFAULT NULL,
  `teacher_department` int(11) UNSIGNED DEFAULT NULL,
  `teacher_status` varchar(10) DEFAULT 'unregister',
  `teacher_secretquestion` varchar(250) DEFAULT NULL,
  `teacher_secretanswer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`teacher_ID`),
  UNIQUE KEY `teacher_facultyID` (`teacher_facultyID`),
  KEY `teacher_userID` (`teacher_userID`),
  KEY `teacher_department` (`teacher_department`),
  KEY `teacher_civilStat` (`teacher_civilStat`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_teacher_detail`
--

INSERT INTO `user_teacher_detail` (`teacher_ID`, `teacher_userID`, `teacher_img`, `teacher_facultyID`, `teacher_fName`, `teacher_mName`, `teacher_lName`, `teacher_gender`, `teacher_dob`, `teacher_contact`, `teacher_address`, `teacher_civilStat`, `teacher_department`, `teacher_status`, `teacher_secretquestion`, `teacher_secretanswer`) VALUES
(130, 8, 'temp.gif', 68, 'sarada', '', 'uchiha', 'F', '2018-01-28', '123123', '123123', 1, 2, 'register', '', ''),
(140, 17, 'temp.gif', 54, 'z', 'z', 'z', 'M', '0004-08-05', '85', 'z', 1, 1, 'register', '', ''),
(142, 20, 'temp.gif', 654, 'asd', 'asd', 'asd', 'M', '1689-09-01', '654', 'asd', 1, 1, 'register', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `view_counter`
--

DROP TABLE IF EXISTS `view_counter`;
CREATE TABLE IF NOT EXISTS `view_counter` (
  `view_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `view_topicID` int(11) UNSIGNED DEFAULT NULL,
  `view_count` int(11) DEFAULT '0',
  PRIMARY KEY (`view_ID`),
  KEY `view_topicID` (`view_topicID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `view_counter`
--

INSERT INTO `view_counter` (`view_ID`, `view_topicID`, `view_count`) VALUES
(3, 15, 16),
(4, 16, 6),
(5, 17, 6);

-- --------------------------------------------------------

--
-- Table structure for table `virtualmeeting`
--

DROP TABLE IF EXISTS `virtualmeeting`;
CREATE TABLE IF NOT EXISTS `virtualmeeting` (
  `virtualmeeting_id` int(11) NOT NULL AUTO_INCREMENT,
  `virtualmeeting_time` varchar(555) NOT NULL,
  `virtualmeeting_description` varchar(555) NOT NULL,
  `virtualmeeting_type` varchar(555) NOT NULL,
  PRIMARY KEY (`virtualmeeting_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `forum_comment`
--
ALTER TABLE `forum_comment`
  ADD CONSTRAINT `forum_comment_ibfk_1` FOREIGN KEY (`comment_topicID`) REFERENCES `forum_topic` (`topic_ID`),
  ADD CONSTRAINT `forum_comment_ibfk_2` FOREIGN KEY (`comment_userID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `forum_comment_reply`
--
ALTER TABLE `forum_comment_reply`
  ADD CONSTRAINT `forum_comment_reply_ibfk_1` FOREIGN KEY (`comment_reply_parentID`) REFERENCES `forum_comment` (`comment_ID`),
  ADD CONSTRAINT `forum_comment_reply_ibfk_2` FOREIGN KEY (`comment_reply_userID`) REFERENCES `user_account` (`user_ID`),
  ADD CONSTRAINT `forum_comment_reply_ibfk_3` FOREIGN KEY (`comment_reply_topicID`) REFERENCES `forum_topic` (`topic_ID`);

--
-- Constraints for table `forum_topic`
--
ALTER TABLE `forum_topic`
  ADD CONSTRAINT `forum_topic_ibfk_1` FOREIGN KEY (`post_owner_id`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `message_send`
--
ALTER TABLE `message_send`
  ADD CONSTRAINT `message_send_ibfk_1` FOREIGN KEY (`message_threadID`) REFERENCES `message_thread` (`thread_ID`),
  ADD CONSTRAINT `message_send_ibfk_2` FOREIGN KEY (`message_receiver`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `message_send_state`
--
ALTER TABLE `message_send_state`
  ADD CONSTRAINT `message_send_state_ibfk_1` FOREIGN KEY (`state_msgID`) REFERENCES `message_send` (`message_ID`),
  ADD CONSTRAINT `message_send_state_ibfk_2` FOREIGN KEY (`state_readerID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `message_thread_participant`
--
ALTER TABLE `message_thread_participant`
  ADD CONSTRAINT `message_thread_participant_ibfk_1` FOREIGN KEY (`participant_threadID`) REFERENCES `message_thread` (`thread_ID`),
  ADD CONSTRAINT `message_thread_participant_ibfk_2` FOREIGN KEY (`participant_userID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `mmu_course`
--
ALTER TABLE `mmu_course`
  ADD CONSTRAINT `mmu_course_ibfk_1` FOREIGN KEY (`course_departmentID`) REFERENCES `mmu_department` (`department_ID`);

--
-- Constraints for table `mmu_department`
--
ALTER TABLE `mmu_department`
  ADD CONSTRAINT `mmu_department_ibfk_1` FOREIGN KEY (`department_collegeID`) REFERENCES `mmu_college` (`colleges_ID`);

--
-- Constraints for table `suggested_job`
--
ALTER TABLE `suggested_job`
  ADD CONSTRAINT `suggested_job_ibfk_1` FOREIGN KEY (`job_Course`) REFERENCES `mmu_course` (`course_ID`);

--
-- Constraints for table `survey_forms`
--
ALTER TABLE `survey_forms`
  ADD CONSTRAINT `survey_forms_ibfk_1` FOREIGN KEY (`form_ownerID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `survey_maxcount`
--
ALTER TABLE `survey_maxcount`
  ADD CONSTRAINT `survey_maxcount_ibfk_1` FOREIGN KEY (`survey_ownerID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `survey_question4`
--
ALTER TABLE `survey_question4`
  ADD CONSTRAINT `survey_question4_ibfk_1` FOREIGN KEY (`survey_formID`) REFERENCES `survey_forms` (`form_id`);

--
-- Constraints for table `survey_question5`
--
ALTER TABLE `survey_question5`
  ADD CONSTRAINT `survey_question5_ibfk_1` FOREIGN KEY (`survey_formID`) REFERENCES `survey_forms` (`form_id`);

--
-- Constraints for table `survey_question6`
--
ALTER TABLE `survey_question6`
  ADD CONSTRAINT `survey_question6_ibfk_1` FOREIGN KEY (`survey_formID`) REFERENCES `survey_forms` (`form_id`);

--
-- Constraints for table `user_account`
--
ALTER TABLE `user_account`
  ADD CONSTRAINT `user_account_ibfk_1` FOREIGN KEY (`user_level`) REFERENCES `user_level` (`level_ID`);

--
-- Constraints for table `user_admin_detail`
--
ALTER TABLE `user_admin_detail`
  ADD CONSTRAINT `user_admin_detail_ibfk_1` FOREIGN KEY (`admin_userID`) REFERENCES `user_account` (`user_ID`),
  ADD CONSTRAINT `user_admin_detail_ibfk_2` FOREIGN KEY (`admin_civilStat`) REFERENCES `marital_status` (`ID`);

--
-- Constraints for table `user_notification`
--
ALTER TABLE `user_notification`
  ADD CONSTRAINT `user_notification_ibfk_2` FOREIGN KEY (`notif_userID`) REFERENCES `user_account` (`user_ID`),
  ADD CONSTRAINT `user_notification_ibfk_3` FOREIGN KEY (`notif_receiverID`) REFERENCES `user_account` (`user_ID`);

--
-- Constraints for table `user_student_detail`
--
ALTER TABLE `user_student_detail`
  ADD CONSTRAINT `user_student_detail_ibfk_1` FOREIGN KEY (`student_department`) REFERENCES `mmu_course` (`course_ID`),
  ADD CONSTRAINT `user_student_detail_ibfk_2` FOREIGN KEY (`student_userID`) REFERENCES `user_account` (`user_ID`),
  ADD CONSTRAINT `user_student_detail_ibfk_3` FOREIGN KEY (`student_civilStat`) REFERENCES `marital_status` (`ID`);

--
-- Constraints for table `user_teacher_detail`
--
ALTER TABLE `user_teacher_detail`
  ADD CONSTRAINT `user_teacher_detail_ibfk_1` FOREIGN KEY (`teacher_userID`) REFERENCES `user_account` (`user_ID`),
  ADD CONSTRAINT `user_teacher_detail_ibfk_2` FOREIGN KEY (`teacher_department`) REFERENCES `mmu_department` (`department_ID`),
  ADD CONSTRAINT `user_teacher_detail_ibfk_3` FOREIGN KEY (`teacher_civilStat`) REFERENCES `marital_status` (`ID`);

--
-- Constraints for table `view_counter`
--
ALTER TABLE `view_counter`
  ADD CONSTRAINT `view_counter_ibfk_1` FOREIGN KEY (`view_topicID`) REFERENCES `forum_topic` (`topic_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
